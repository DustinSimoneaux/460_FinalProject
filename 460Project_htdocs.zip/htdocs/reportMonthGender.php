<?php 
session_start();
if ($_SESSION['Username'] == 'Admin') {
	echo file_get_contents("header.html");
}
else {
	echo file_get_contents("header2.html");
}

$servername = "localhost";// sql server machine name/IP (if your computer is the server too, then just keep it as "localhost"). 
$username = "root";// mysql username
$password = "";// sql password
$dbname  = "project";// database name

	// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
echo 'Example: April of 2004 would be 04/2004';
echo "<br>";
if(isset($_POST['inserttb'])){ //things to do, once the "submit" key is hit
	$date=$_POST['dtb'];
	$G=$_POST['gtb'];
	$result = $conn->query("SELECT Count(Join_Date) FROM User WHERE Join_Date='$date' and Gender = '$G'");
	$count = mysqli_fetch_row($result);
		
	echo "The amount of $G users who joined in $date is $count[0]";
}

?>
<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
Insert month/year : <input type ="text" name ="dtb"/>
<br/> <br/>
Insert Gender (M or F): <input type ="text" name ="gtb"/>
<br/> <br/>

<input type ="submit" value="Insert" name="inserttb"/>
</form>