<?php 
session_start();
if ($_SESSION['Username'] == 'Admin') {
	echo file_get_contents("header.html");
}
else {
	echo file_get_contents("header2.html");
}

$servername = "localhost";                                          // sql server machine name/IP (if your computer is the server too, then just keep it as "localhost"). 
$username = "root";                                                 // mysql username
$password = "";                                                     // sql password
$dbname  = "project";                                               // database name


$conn = new mysqli($servername, $username, $password, $dbname);     // Create connection

if(isset($_POST['inserttb'])){                                   	// Things to do, once the "submit" key is hit

	$year=$_POST['ytb'];
	
	$result = $conn->query("SELECT Count(Join_Date) FROM User WHERE Join_Date LIKE '%$year'");
	$count = mysqli_fetch_row($result);
		
		echo "The amount of users joined in $year is $count[0]";
}



?>
<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
Insert 4 digit year : <input type ="text" name ="ytb"/>
<br/> <br/>

<input type ="submit" value="Search" name="inserttb"/>
</form>