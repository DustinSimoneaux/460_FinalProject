<!--
This php file is used to view items on the menu.
-->
<?php 
session_start();
if ($_SESSION['Username'] == 'Admin') {
	echo file_get_contents("header.html");
}
else {
	echo file_get_contents("header2.html");
}
?>

<html>
<body>
<?php
$servername = "localhost";											// sql server machine name/IP (if your computer is the server too, then just keep it as "localhost"). 
$username = "root";													// mysql username
$password = "";														// sql password
$dbname  = "project";												// database name

$conn = new mysqli($servername, $username, $password, $dbname);		// Create connection
$result = $conn->query("SELECT Item, Price FROM Food");

echo "<table>"; 													// Start a table tag in the HTML

while($row = mysqli_fetch_array($result)){   						// Creates a loop to loop through results
	echo "<tr><td>" . $row['Item'] . "</td><td>" . $row['Price'] . "</td></tr>";  
	}

echo "</table>"; 													// Close the table in HTML
?>