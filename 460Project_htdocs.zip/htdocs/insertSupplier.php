<!--
This php file is used to insert data in Supplier table
Here we are submitting the form to the same page.
-->
<?php echo file_get_contents("header.html"); 
session_start();
?>

<html>
	<head>
		<title>Cajun Cookers | Add Food</title>
	</head>
<body>
<?php
// Admin user for food insertion:   
//                                      Username:   Admin
//                                      Password:   295FineTaste!
//

if(isset($_POST['inserttb'])){          // things to do, once the "submit" key is hit


        $Supplier=$_POST['SPtb'];           // get form value Supplier attribute
        $Supplier_Contact=$_POST['SCtb'];   // get form value Supplier_Contact attribute
	

	$servername = "localhost";          // sql server machine name/IP (if your computer is the server too, then just keep it as "localhost"). 
	$username = "root";                 // mysql username
	$password = "";                     // sql password
	$dbname  = "project";               // database name


	//          +++ Create connection +++ 
	$conn = new mysqli($servername, $username, $password, $dbname);
	
	// 			 Get the authorized user
	$result = $conn->query("SELECT Password FROM User WHERE Username = 'Admin'");
	if($result->num_rows == 0) {
    	$hash = Null;
	} 
	else {
  		$hash = $result;
	}
	
	//          +++ If the Admin is logged in, place the order request +++
	
	if ($_SESSION['Username']=='Admin'){
		$sql = "INSERT INTO Supplier VALUES ('$Supplier','$Supplier_Contact')";
		$result = $conn->query($sql);
		if($result)         // If the insert into database was successful
		{
		echo 'Supplier successfully inserted';
		}
	}
	else{
		echo 'You do not have authorization';
	}
}
?>

<!-- The following piece of code is run when the page is loaded (before submit button is hit) -->
<!-- "form" is an HTML tag that enable us to have components such as textbox and buttons in the html page.
"action" part determines the page where the information of the current form (page) should be sent.
"method" part determines if the data in the current form is sent/received to/from another page.
The value of "method" is generally "post". -->
<!--
Here we use $_SERVER['PHP_SELF'] which returns the current page. Here it return insert.php
-->
<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
<br/>	<!-- The <br> tag inserts a single line break.-->

<!-- Below, we define components existing in the page (textboxes and submit button) -->
Supplier : <input type ="text" name ="SPtb"/>
<br/> <br/>
Supplier_Contact : <input type ="text" name ="SCtb"/>
<br/> <br/>
<input type ="submit" value="Insert" name="inserttb"/>
</form>