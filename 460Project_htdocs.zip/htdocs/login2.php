<!DOCTYPE html>
<html lang="en">
   <head>
      <title>Cajun Cookers | Login</title>
      <meta charset="UTF-8">
      <meta name="description" contents="Choose Your action">
      <link rel="stylesheet" href="style.css" type="text/css">
   </head>
   <body>         
      <header>
         <nav id="navigation">
            <ul>
               <li><a href="Home.php">Home</a></li>
               <li><a href="insertUser.php">Register</a></li>

            </ul>
         </nav>
      </header>
<?php
   include("Config.php");
   session_destroy();
   session_start();

   if($_SERVER["REQUEST_METHOD"] == "POST") {
      // username and password sent from form 
      $_SESSION["Username"] = mysqli_real_escape_string($db,$_POST['Usernametb']);
      $_SESSION["Password"] = mysqli_real_escape_string($db,$_POST['Passwordtb']); 
   


      $servername = "localhost";          // sql server machine name/IP (if your computer is the server too, then just keep it as "localhost"). 
      $username = "root";                 // mysql username
      $password = "";                     // sql password
      $dbname  = "project";               // database name

      //          +++ Create connection +++ 
      $conn = new mysqli($servername, $username, $password, $dbname);

      $result = $conn->query("SELECT Password FROM User WHERE Username = '$_SESSION[Username]'");


      if($result->num_rows == 0) {
      $hash=Null;
      } 
      else {
         $hash=$result->fetch_object()->Password;
      }
      

      
      // If result matched $myusername and $mypassword, table row must be 1 row
   
      if (password_verify($_SESSION['Password'],$hash) and $_SESSION['Username'] == 'Admin') {

         $_SESSION['login_user'] = $Username;
         $_SESSION['login'] = true;
         header("location: index.php");
      }
      elseif (password_verify($_SESSION['Password'],$hash)) {

         $_SESSION['login_user'] = $Username;
         $_SESSION['login'] = true;
         header("location: index2.php");
      }   
      else {
         $error = "Your Login Name or Password is invalid";
      }
   }
?>
<html>
   
   <head>
      <title>Login Page</title>
      
      <style type = "text/css">
         body {
            font-family:Arial, Helvetica, sans-serif;
            font-size:14px;
         }
         label {
            font-weight:bold;
            width:100px;
            font-size:14px;
         }
         .box {
            border:#666666 solid 1px;
         }
      </style>
      
   </head>
   
   <body bgcolor = "#FFFFFF">
	
      <div align = "center">
         <div style = "width:300px; border: solid 1px #333333; " align = "left">
            <div style = "background-color:#333333; color:#FFFFFF; padding:3px;"><b>Login</b></div>
				
            <div style = "margin:30px">
               
               <form action = "" method = "post">
                  <label>UserName  :</label><input type = "text" name = "Usernametb" class = "box"/><br /><br />
                  <label>Password  :</label><input type = "password" name = "Passwordtb" class = "box" /><br/><br />
                  <input type = "submit" value = " Submit "/><br />
               </form>
               
              			
            </div>
				
         </div>
			
      </div>

   </body>
</html>