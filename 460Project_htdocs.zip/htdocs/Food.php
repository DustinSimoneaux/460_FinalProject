<!--
This php file is used to insert data in Food table
Here we are submitting the form to the same page.
-->
<?php 
session_start();
echo file_get_contents("header.html"); ?>

<html>
	<head>
		<title>Cajun Cookers | Add Food</title>
	</head>
<body>
<?php

// Admin user for food insertion:   
//                                      Username:   Admin
//                                      Password:   295FineTaste!
//

if(isset($_POST['inserttb'])){          // things to do, once the "submit" key is hit

	$Item_ID=$_POST['IIDtb'];           // get form value Item_ID attribute
    $Item=$_POST['ITtb'];               // get form value Item_ID attribute
	$Price=$_POST['PRtb'];              // get form value Price attribute
	$Stock = $_POST['STtb'];            // get form values Stock attribute
	$Reorder_Amount = $_POST['RAtb'];   // get form value Reorder_Amount attribute
    $Supplier=$_POST['SPtb'];           // get form value Supplier attribute	

	$servername = "localhost";          // sql server machine name/IP (if your computer is the server too, then just keep it as "localhost"). 
	$username = "root";                 // mysql username
	$password = "";                     // sql password
	$dbname  = "project";               // database name


	//          +++ Create connection +++ 
	$conn = new mysqli($servername, $username, $password, $dbname);
	
	
	if ($_SESSION['Username'] == 'Admin') {						//          +++ If the admin is logged in propeprly, allow for insertion +++
		$sql = "INSERT INTO Food VALUES ('$Item_ID','$Item','$Price', '$Stock', '$Reorder_Amount', '$Supplier')";
		$result = $conn->query($sql);

		if($result)         // If the insert into database was successful
		{
			echo 'Food successfully placed';
		}
		else{
			echo 'ERROR: There was an issue inserting your item into the database.';
		}
		
	}
		
}
?>

<!-- The following piece of code is run when the page is loaded (before submit button is hit) -->
<!-- "form" is an HTML tag that enable us to have components such as textbox and buttons in the html page.
"action" part determines the page where the information of the current form (page) should be sent.
"method" part determines if the data in the current form is sent/received to/from another page.
The value of "method" is generally "post". -->
<!--
Here we use $_SERVER['PHP_SELF'] which returns the current page. Here it return insert.php
-->
<style>
	ul {
		margin: 0;
		padding: 0;
		list-style: none;
		background-color: none;
	}

	form {
		margin: 30px auto;
		width: 500px;
		padding: 1em;
		border: 1px solid #CCC;
		border-radius: 1em;
		background-image: linear-gradient(dimgray, white); background-attachment: fixed;
	}

	div+div {
		margin-top: 1em;
	}

	label span {
		display: inline-block;
		width: 170px;
		text-align: left;
		padding-left: 0;
		
		font-size: 115%;
		color: white;
	}

	input, textarea {
		display: inline-block;
		font: 1em sans-serif;
		width: 210px;
		box-sizing: border-box;
		border: 1px solid #999;
		
	}

	input[type=checkbox], input[type=radio] {
		width: auto;
		border: none;
	}

	input:focus, textarea:focus {
		border-color: #000;
	}

	textarea {
		vertical-align: top;
		height: 5em;
		resize: vertical;
	}

	fieldset {
		width: 450px;
		box-sizing: border-box;
		margin-left: 25px;
		border: 1px solid #999;
		background-image: linear-gradient(black, grey); background-attachment: fixed;
	}

	

	label {
		position: relative;
	}

	label em {
		position: absolute;
		right: 15px;
		top: 15px;
	}
	p {
		color:
	}
</style>
<section>
	<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
	<br/>
	<!-- Below, we define components existing in the page (textboxes and submit button) -->
		<fieldset>
				<p>
					<label for="itemID">
						<span>Item_ID: </span>
					</label>
					<input type="text" id="itemID" name="IIDtb"/>								
					<br/> <br/>
				</p>
				<p>
					<label for="item">				
						<span>Item: </span>
					</label>
					<input type="text" id="item" name="ITtb"/>				
					<br/> <br/>
				</p>
				<p>
					<label for="price">				
						<span>Price: </span>
					</label>
					<input type="text" id="price" name="PRtb"/>				
					<br/> <br/>
				</p>
				<p>
					<label for="stock">				
						<span>Stock: </span>
					</label>
					<input type ="text" id="stock" name ="STtb"/>				
					<br/> <br/>
				</p>
				<p>
					<label for="reorderAmount">				
						<span>ReorderAmount: </span>
					</label>
					<input type ="text" id="reorderAmount" name ="RAtb"/>				
					<br/> <br/>
				</p>
				<p>
					<label for="supplier">				
						<span>Supplier: </span>
					</label>
					<input type ="text" id="supplier" name ="SPtb"/>				
					<br/> <br/>
				</p>

				<p>
					<label for="submit">
					<input type ="submit" value="Insert" id="submit" name="inserttb"/>					
				</p>
			
		</fieldset>
	</form>
</section>