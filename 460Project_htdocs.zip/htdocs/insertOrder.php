<!--
This php file is used to insert data in Persons table
Here we are submitting the form to the same page.
-->
<html>
	<head>
		<title>Cajun Cookers | Create Order</title>
	</head>
<body>
<?php 
session_start();
if ($_SESSION['Username'] == 'Admin') {
	echo file_get_contents("header.html");
 }
 else {
	echo file_get_contents("header2.html");
 }
?>

<?php 
$servername = "localhost";											// sql server machine name/IP (if your computer is the server too, then just keep it as "localhost"). 
$username = "root";													// mysql username
$password = "";														// sql password
$dbname  = "project";												// database name
	
$conn = new mysqli($servername, $username, $password, $dbname);		// Create connection	
$result = $conn->query("SELECT Item_ID,Item,Price FROM Food");
?>

<body bgcolor = "#FFFFFF">                          
	<div align = "left">
		<div style = "width:250px; border: solid 1px #333333; background-color: white" align = "left">
			<div style = "background-color:#333333; color:#FFFFFF; padding:2px;"><b>Menu</b></div>	
			<div style = "margin:30px">
			<style type="text/css">
					main {
						display: flex; 
						justify-content: center;
					}
					table {
						border-spacing: 0px;
						max-width: 100%;
						column-gap: 0px;
					}
					tr:nth-child(odd) {
						background-color: #eee;
					}
					th {
						display: table-cell;
						column-gap: 1px;
						align: center;
						background-color: #555; 
						color: #fff; 
					}
					table,
					th,
					td {
						border: 1px solid #555;
					}
					th,
					td {
						text-align: center; 
						padding: 0.5em 0.5em;
					}
			</style>
			<main>
				<table>
				<tr>
					<th>Item_ID</th>
					<th>Item</th>
					<th>Price</th>
				</tr>
				<?php while($row = mysqli_fetch_array($result)){   //Creates a loop to loop through results
						echo '<tr><td>'.$row['Item_ID'].'</td><td>'.$row['Item'].'</td><td>$'.$row['Price']."</td></tr>";  
					} ?>
				</table>
			</main>
												
			</div>                            
		</div>                        
	</div>
</body>

<?php 
if(isset($_POST['inserttb'])){ 									// things to do, once the "submit" key is hit
	
	$Item_ID = $_POST['IIDtb'];									// get form values Item_ID attribute
	
	$Quantity = $_POST['QNtb'];									// get form value Quantity attribute
	$sql = "SELECT Price FROM Food WHERE Item_ID=$Item_ID";    	// embed insert statement in PHP
	$result = $conn->query($sql);
    $price=(mysqli_fetch_row($result));
    $total=$price[0]*$Quantity;
	
	$UN=$_SESSION['Username'];
	$r = $conn->query("SELECT Count(Username) FROM Orders");
	$count = mysqli_fetch_row($r);
    $type=gettype($count[0]);

	$sql = "INSERT INTO Orders VALUES ('$UN', '$count[0]', '$Quantity', '$Item_ID', 'NULL')";	// embed insert statement in PHP
	$result = $conn->query($sql);

	if($result)     // if the insert into database was successful
    {
    	$sql = "SELECT Item FROM Food WHERE Item_ID=$Item_ID";    // embed insert statement in PHP
    	$result = $conn->query($sql);

    	if($result)
		{
        	$Item=mysqli_fetch_row($result);
			if ($Quantity == 1) {
        		echo "Order successfully placed<br>Your total price is  $$total for $Quantity $Item[0]";
			}
			else {
				echo "Order successfully placed<br>Your total price is  $$total for $Quantity $Item[0]s";
			}
        }
    	else {	
			echo"Error with the price";
		}
    }
    else {
		echo"Error with placing order";
	}
}
?>
<!-- The following piece of code is run when the page is loaded (before submit button is hit) -->
<!-- "form" is an HTML tag that enable us to have components such as textbox and buttons in the html page.
"action" part determines the page where the information of the current form (page) should be sent.
"method" part determines if the data in the current form is sent/received to/from another page.
The value of "method" is generally "post". -->
<!--
Here we use $_SERVER['PHP_SELF'] which returns the current page. Here it return insert.php
-->
<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
<br/>	<!-- The <br> tag inserts a single line break.-->
<!-- Below, we define components exist in the page (textboxes and submit button) -->

Item_ID: 
<input type ="text" name ="IIDtb"/>
<br/> <br/>

Quantity: 
<input type ="text" name ="QNtb"/>
<br/> <br/>

<input type ="submit" value="Insert" name="inserttb"/>
</form>
</body>
</html>