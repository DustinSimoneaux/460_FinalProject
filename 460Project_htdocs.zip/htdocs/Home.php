
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="description" contents="Choose Your action">
        <link rel="stylesheet" href="style.css" type="text/css">
    </head>
    <body style="background-color:#811300;">
        <header>
            <nav id="navigation">
                <ul>
                    <li><a href="login2.php">Login</a></li>
                    <li><a href="insertUser.php">Register</a></li>
                </ul>
            </nav>
        </header>
        <div id="contents">
            <p style="color: white">
                Welcome to Cajun Cookers! With our website, you can make an account and login in order to create an order to be delivered to you.
            </p>
            <hr>
            <p style="color: grey">
                If at any point you decide that you no longer want to be a member, feel free to delete your account at any time. Otherwise, get started by looking at our menu and creating your first order!
            </p>
            <?php 

            $servername = "localhost";                                          // sql server machine name/IP (if your computer is the server too, then just keep it as "localhost"). 
            $username = "root";                                                 // mysql username
            $password = "";                                                     // sql password
            $dbname  = "project";                                               // database name
            
            $conn = new mysqli($servername, $username, $password, $dbname);     // Create connection
            $result = $conn->query("SELECT Item, Price FROM Food");
            ?>
            <head>
                <title>Cajun Cookers | Home Page</title>
                
                <style type = "text/css">
                    body {
                        font-family:Arial, Helvetica, sans-serif;
                        font-size:14px;
                    }
                    label {
                        font-weight:bold;
                        width:100px;
                        font-size:14px;
                    }
                    .box {
                        border:#666666 solid 1px;
                    }
                </style>
                
            </head>
            <body bgcolor = "#FFFFFF">
                
                
                <div align = "center">
                    <div style = "width:150px; border: solid 1px #333333; background-color: white" align = "left">
                        <div style = "background-color:#333333; color:#FFFFFF; padding:2px;"><b>Menu</b></div>
                            
                        <div style = "margin:30px">
                        <style type="text/css">
                                main {
                                    display: flex; 
                                    justify-content: center;
                                }
                                table {
                                    border-spacing: 0px;
                                    max-width: 100%;
                                    column-gap: 0px;
                                }
                                tr:nth-child(odd) {
                                    background-color: #eee;
                                }
                                th {
                                    display: table-cell;
                                    column-gap: 1px;
                                    align: center;
                                    background-color: #555; 
                                    color: #fff; 
                                }
                                table,
                                th,
                                td {
                                    border: 1px solid #555;
                                }
                                th,
                                td {
                                    text-align: center; 
                                    padding: 0.5em 0.5em;
                                }
                        </style>
                        <main>
                            <table>
                            <tr>
                                <th>Item</th>
                                <th>Price</th>
                            </tr>
                            <?php while($row = mysqli_fetch_array($result)){                                //Creates a loop to loop through results
                                    echo '<tr><td>'.$row['Item'].'</td><td>$'.$row['Price']."</td></tr>";  
                                } ?>
                            </table>
                            </main>
                                                            
                        </div>                            
                    </div>                        
                </div>
            </body>
        </div>
        <style>
            footer {
                position: absolute;
                left: 0;
                bottom: 0;
                width: 100%;
                font-size: relative;
                background-color: white;
                color: black;
                text-align: center;
                font-family: "copperplate", fantasy;
            }
        </style>
        <footer>
            Thanks for using our app!
        </footer>
    </body>
</html>