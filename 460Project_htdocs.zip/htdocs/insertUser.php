<!--
This php file is used to insert data in Persons table
Here we are submitting the form to the same page.
-->
<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Cajun Cookers | Register</title>
        <meta charset="UTF-8">
        <meta name="description" contents="Choose Your action">
        <link rel="stylesheet" href="style.css" type="text/css">
    </head>
    <body style="background-image: linear-gradient(rgb(201, 67, 67), rgb(187, 179, 75)); background-attachment: fixed;">         
         <header>
            <nav id="navigation">
                <ul>
                    <li><a href="Home.php">Home</a></li>
                    <li><a href="login2.php">Login</a></li>
                </ul>
            </nav>
        </header>
<?php

if(isset($_POST['inserttb'])){ 				// things to do, once the "submit" key is hit

	$UN = $_POST['UNtb'];					// get form value Username attribute
	$PW = $_POST['PWtb'];					// get form value Password attribute
	$VPW = $_POST['VPWtb']; 				// get form value to verify Password attribute
	$fn = $_POST['FNtb'];					// get form values First Name attribute
	$ln = $_POST['LNtb'];					// get form value Last Name attribute
	$Birth_Year = $_POST['BYtb'];			// get form value Birth_Year attribute
	$Gender = $_POST['Gtb'];				// get form value Gender attribute
	$Join_Date = date('m/Y');				// get date for the Join_Date attribute

	$servername = "localhost";				// sql server machine name/IP (if your computer is the server too, then just keep it as "localhost"). 
	$username = "root";						// mysql username
	$password = "";							// sql password
	$dbname  = "project";					// database name
	
	if ($Gender=='M' or $Gender=='F'){		// checks if gender is valid
		$GValid=True;
	}
	else{
		$GValid=False;
	}

	// Create connection. Only insert if passwords match, username is unique, and gender is valid
	$conn = new mysqli($servername, $username, $password, $dbname);

	// Checks if username already exists
	$result = $conn->query("SELECT Username FROM User WHERE Username = '$UN'");
	if($result->num_rows == 0) {
    	$UNFound=False;
	} 
	else {
  		$UNFound=True;
	}

	if ($PW==$VPW and !$UNFound and $GValid){
		$PWH = password_hash($PW,PASSWORD_DEFAULT);
		$sql = "INSERT INTO User VALUES ('$UN', '$PWH', '$fn', '$ln', '$Birth_Year', '$Gender', '$Join_Date')";	// Embed insert statement in PHP
		$result = $conn->query($sql);

		// If the insert into database was successful
		if($result){ 
			if (password_verify($PW,$PWH) and $UN == 'Admin') {

				$_SESSION['login_user'] = $Username;
				$_SESSION['login'] = true;
				header("location: index.php");
			 }
			 elseif (password_verify($PW,$PWH)) {
	   
				$_SESSION['login_user'] = $Username;
				$_SESSION['login'] = true;
				header("location: index2.php");
			 }
		}
		
	}
	elseif ($PW!==$VPW){
		echo "Passwords do not Match.";
	}
	elseif($UNFound){
		echo "That username already exists.";
	}
	else{
		echo "Please insert a correct Gender (M or F)";
	}


}

?>

<!-- The following piece of code is run when the page is loaded (before submit button is hit) -->
<!-- "form" is an HTML tag that enable us to have components such as textbox and buttons in the html page.
"action" part determines the page where the information of the current form (page) should be sent.
"method" part determines if the data in the current form is sent/received to/from another page.
The value of "method" is generally "post". -->
<!--
Here we use $_SERVER['PHP_SELF'] which returns the current page. Here it return insert.php
-->

<style>
	ul {
		margin: 0;
		padding: 0;
		list-style: none;
		background-color: none;
	}

	form {
		margin: 30px auto;
		width: 500px;
		padding: 1em;
		border: 1px solid #CCC;
		border-radius: 1em;
		background-color: white;
	}

	div+div {
		margin-top: 1em;
	}

	label span {
		display: inline-block;
		width: 170px;
		text-align: right;
		padding-left: 0;
		font-family: "copperplate", fantasy;
		font-size: 115%;
		color: black;
	}

	input, textarea {
		display: inline-block;
		font: 1em sans-serif;
		width: 210px;
		box-sizing: border-box;
		border: 1px solid #999;
	}

	input[type=checkbox], input[type=radio] {
		width: auto;
		border: none;
	}

	input:focus, textarea:focus {
		border-color: #000;
	}

	textarea {
		vertical-align: top;
		height: 5em;
		resize: vertical;
	}

	fieldset {
		width: 450px;
		box-sizing: border-box;
		margin-left: 25px;
		border: 1px solid #999;
		background-color: dimgrey;
	}

	label {
		position: relative;
	}

	label em {
		position: absolute;
		right: 15px;
		top: 15px;
	}

	p {
		color: black;
	}
</style>
<section>
	<!-- Below, we define components exist in the page (textboxes and submit button) -->
	<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
	<br/>
		<fieldset>
			<p>
				<label for="username">
					<span>Username: </span>
				</label>
				<input type="text" id="username" name="UNtb"/> 
				<br/> <br/>
			</p>
			<p>
				<label for="password">
					<span>Password: </span>
				</label>
				<input type="text" id="password" name="PWtb"/>
				<br/> <br/>
			</p>
			<p>
				<label for="retypepassword">
					<span>Retype Password: </span>
				</label>
				<input type="text" id="retypepassword" name="VPWtb"/>
				<br/> <br/>
			</p>
			<p>
				<label for="firstname">
					<span>First Name: </span>
				</label>
				<input type ="text" id="firstname" name ="FNtb"/>
				<br/> <br/>
			</p>
			<p>
				<label for="lastname">
					<span>Last Name: </span>
				</label>
				<input type="text" id="lastname" name="LNtb"/>
				<br/> <br/>
			</p>
			<p>
				<label for="birthyear">
					<span>Birth Year: </span>
				</label>
				<input type="text" id="birthyear" name="BYtb"/>
				<br/> <br/>
			</p>
			<p>
				<label for="gender">
					<span>Gender (M or F): </span>
				</label>
				<input type ="text" id="gender" name ="Gtb"/>
				<br/> <br/>
			</p>
			<p>
				<label for="submit">
				<input type ="submit" value="Insert" id="submit" name="inserttb"/>
			</p>
		</fieldset>
	</form>
</section>
