<!--
This file is used to delete a record from database
-->
<?php 
session_start();
if ($_SESSION['Username'] == 'Admin') {
	echo file_get_contents("header.html");
}
else {
	echo file_get_contents("header2.html");
}
?>

<html>
    <head>
        <title>Cajun Cookers | Delete Account</title>
    </head>
<body>

<?php
if (!empty($_SESSION['Username'])){
    $UN = $_SESSION['Username'];                            // Get the id value from url parameters
}

$servername = "localhost";                                  // SQL server name
$username = "root";                                         // SQL username
$password = "";                                             // SQL password
$dbname  = "project";                                       // Database name


//          +++ Create connection +++                       //
$conn = new mysqli($servername, $username, $password, $dbname);


if(isset($_GET['mode']) == 'delete'){

    $sqldelete = "DELETE FROM User WHERE Username='$UN'";   // Delete statement
    $delete = $conn->query($sqldelete);                     // Execute the query
    if($delete)
    { 
        header("location: Home.php");;
    }
}

//          +++ Below is the code to show the list of records +++           //

$sql = "SELECT Username FROM User WHERE Username = $_SESSION[Username]";  	// Embed a select statement
$result = $conn->query($sql);	// Get result

echo "<table style='border: solid 2px black;'>
	<tr>
	    <th>| Username |</th>
	</tr>";



// Store the result in an array, then put them in html table one by one
echo '<tr>
	<td>'.$_SESSION['Username'].'</td>

<!-- below, creates a hyperlink (Delete) and change the mode to "delete". Please note that the link is redirected to the same page (href="delete.php"). -->
		<td> <a href="delete.php?Username='.$_SESSION['Username'].'&mode=delete">Delete </a></td>
	      </tr>';

echo "</table>";


?>
</body>
</html>