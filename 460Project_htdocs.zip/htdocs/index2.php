<?php session_start();?>
<html>
	<head>
		<?php echo '<title>Cajun Cookers | '.$_SESSION["Username"].'\'s Home Page</title>'; // Displays logged in Username on the tab ?>
	</head>
<body>
<?php
if(!$_SESSION['login']){                // Redirect to Login if user is not actually logged in
    header("Location:login2.php");
    exit(); 
}
    echo file_get_contents("header2.html"); 
    echo file_get_contents("body2.html"); 
    echo file_get_contents("footer.html"); 
?>