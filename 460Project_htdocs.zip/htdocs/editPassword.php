<!--
This file is used to edit the records in table persons. You do not need to run this by yourself. 
This is called by the editrecord.php.
-->
<html>
    <head>
		<title>Cajun Cookers | Edit Password</title>
	</head>
<?php 
session_start();
if ($_SESSION['Username'] == 'Admin') {
	echo file_get_contents("header.html");
 }
 else {
	echo file_get_contents("header2.html");
 }

?>

<?php
if (!empty($_GET['Password'])){
    $Password = $_GET['Password'];                              // The value of pid is received from the editrecord.php page
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname  = "project";

$conn = new mysqli($servername, $username, $password, $dbname); // Create connection to database

if(isset($_POST['updatebtn']))                                  // Things to do, after the "updatebtn" button is clicked.
{
	$PW=$_POST['PWtb'];
	$PWH=password_hash($PW,PASSWORD_DEFAULT);

	$sql_update= "UPDATE User SET Password ='$PWH' WHERE Username='$_SESSION[Username]'";
	$resultupdate = $conn->query($sql_update);

	if($resultupdate)                                           // If the update is done successfully
		{
		echo "Records updated successfully";
		}
	else{
		echo "Records did not update";
		}
}
?>

<form action="" method="post">
Password : <input type="text" name="PWtb"/>
<br/> <br/>
<input type="submit" value="Update" name="updatebtn"/>
</form>
